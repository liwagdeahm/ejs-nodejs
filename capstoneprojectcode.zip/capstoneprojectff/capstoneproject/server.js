const express = require('express');
const bodyParser = require('body-parser');
const db = require('./routes/db-config');
const cookie = require('cookie-parser');
const mysql = require('mysql');
const session = require('express-session');
require('dotenv').config()

const app = express();


mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"capstone"
})

const users = []

app.set('view engine', 'html');
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'))
app.use(cookie())
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(session({
    secret:"secret",
    resave: false,
    saveUninitialized: false
}))


db.connect((err) => {
    if (err) throw err;
})


/* ----- Product page / Cart Page ----- */

function isProductInCart(cart, productid) {
    for(let i=0; i<cart.length; i++) {
        if(cart[i].productid == productid) {
            return true;
        }
    }
}

function calculateTotal(cart, req) {
    total = 0;
    for(let i=0; i<cart.length; i++) {
        if(cart[i].price) {
            total = total += (cart[i].price*cart[i].qty);
        }
        req.session.total = total;
        return total;
    }
}

app.get('/homepage', (req, res) => {

    var con = mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"",
        database:"capstone"
    })

    con.query("SELECT * FROM uaproducts", (err, result) => {
        res.render('homepage', {result:result});
    }) 
})

app.post('/add-to-cart', function(req, res){

    var productid = req.body.productid;
    var productname = req.body.productname;
    var price = req.body.price;
    var qty = req.body.qty;
    var image = req.body.image;
    var product = {productid:productid, productname:productname, price:price, qty:qty, image:image}

    if(req.session.cart) {
        var cart = req.session.cart;

        if(!isProductInCart(cart, productid)){
            cart.push(product);
        }
    }else {
        req.session.cart = [product];
        var cart = req.session.cart;
    }

    //calculate total
    calculateTotal(cart, req);

    //return to cart page
    res.redirect('/cart');

});

app.get('/cart', function(req, res) {
    var cart = req.session.cart;
    var total = req.session.total;

    res.render('cart', {cart:cart, total:total });

});


app.post('/remove-product', function(req, res) {
    var productid = req.body.productid;
    var cart = req.session.cart;

    for(let i=0; i<cart.length; i++) {
        if(cart[i].productid == productid) {
            cart.splice(cart.indexOf(i), 1)
        }
    }

    //recalculate
    calculateTotal(cart, req);
    res.redirect('cart');
})

app.post('/edit-product-qty', function(req, res) {
    //get values from inputs
    var productid = req.body.productid;
    var qty = req.body.qty;
    var increasebtn = req.body.increase_product_qty;
    var decreasebtn = req.body.decrease_product_qty;

    var cart = req.session.cart;

    if(increasebtn) {
        for(let i=0; i<cart.length; i++) {
            if(cart[i].productid == productid) {

                if(cart[i].qty > 0) {
                    cart[i].qty = parseInt(cart[i].qty)+1;
                }
            }
        }
    }

    if(decreasebtn) {
        for(let i=0; i<cart.length; i++) {
            if(cart[i].productid == productid) {

                if(cart[i].qty > 1) {
                    cart[i].qty = parseInt(cart[i].qty)-1;
                }
            }
        }
    }

    //recalculate
    calculateTotal(cart, req);
    res.redirect('cart');
})



/* ---- Login page ----- */

app.get('/login', (req, res) => {
    res.render('login')
})


/* ----- Checkout ----- */

app.get('/checkout', (req, res) => {
    const cart = req.session.cart;
    const total = req.session.total;

    res.render('checkout', {cart:cart, total:total});
})


/* ----- Receipt ----- */

app.get('/receipt', (req, res) => {
    const cart = req.session.cart;
    const total = req.session.total;

    res.render('receipt', {cart:cart, total:total});
})


/* ---- Admin Login page ----- */

app.post("/adminlogin", function(req,res){
    var email = req.body.email;
    var password = req.body.password;

    db.query("SELECT * FROM adminlogin WHERE email = ? and password = ?", [email, password], async(error, results) => {
        if (results.length > 0) {
            res.redirect('/admin');
        } else {
            res.redirect('/adminlogin');
        }
        res.end();
    })
})

app.get("/adminlogin", (req,res) => {
    res.render("adminlogin");
})


/* ----- Admin Orders ----- */

app.get('/admin', (req, res) => {
    const cart = req.session.cart;
    const total = req.session.total;

    res.render('admin', {cart:cart, total:total});
})


/* ----- Admin Products ----- */

app.get('/adminproducts', (req, res) => {

    db.query("SELECT * FROM allproducts", (err, product) => {
        res.render('prodindex', {product:product});
    }) 
})

app.get('/addproducts', (req, res) => {
    res.render('prodsave');
})

app.post('/save', (req, res) => {

    var con = mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"",
        database:"capstone"
    })

     // const {productname, price, qty } = req.body
    let data = {productname: req.body.productname, price: req.body.price, qty:req.body.qty } = req.body
    let sql = 'INSERT INTO allproducts SET ?';

    let query = con.query(sql, data, (err, results) => {
        if(err) throw err;
        res.redirect('/adminproducts')
    }) 
})

app.get('/edit/:productcode', (req, res ) => {
 
    const productcode = req.params.productcode;
    let sql = `SELECT * FROM allproducts WHERE productcode = ${productcode}`;
    let query = db.query(sql, (err, result) => {
        if(err) throw err;
        res.render('prodedit', {
            product : result[0]
        });
    }) 

})

app.post('/update', (req, res) => {

    const productcode = req.body.productcode;
    let sql = "UPDATE allproducts SET productname='"+req.body.productname+"', price ='"+req.body.price+"', qty ='"+req.body.qty+"' WHERE productcode = "+productcode;

    let query = db.query(sql,(err, results) => {
        if(err) throw err;
        res.redirect('/adminproducts')
    }) 
})

app.get('/delete/:productcode', (req, res ) => {
 
    const productcode = req.params.productcode;
    let sql = `DELETE FROM allproducts WHERE productcode = ${productcode}`;
    let query = db.query(sql, (err, result) => {
        if(err) throw err;
        res.redirect('/adminproducts')
    }) 
})


/* ----- Product Page ----- */

app.get('/idlace', (req, res) => {

    db.query("SELECT * FROM idlace", (err, product) => {
        res.render('idlace', {product:product});
    }) 
})



app.use('/', require('./routes/pages'));
app.use('/auth', require('./controllers/auth'));
app.listen(3000);