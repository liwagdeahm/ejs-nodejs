const express = require('express');
const router = express.Router();


router.get('/register', (req, res) => {
    res.render('register')
})

router.get('/admin', (req, res) => {
    res.render('admin')
})

router.get('/analytics', (req, res) => {
    res.render('analytics')
})

router.get('/books', (req, res) => {
    res.render('books')
})

router.get('/idlace', (req, res) => {
    res.render('idlace')
})

router.get('/adminproducts', (req, res) => {
    res.render('prodindex')
})

router.get('/prodedit', (req, res) => {
    res.render('prodedit')
})

router.get('/adminlogin', (req, res) => {
    res.render('adminlogin')
})

router.get('/checkout', (req, res) => {
    res.render('checkout')
})

router.get('/about', (req, res) => {
    res.render('about')
})

// router.use((req, res, next) => {
//     res.status(404).send('Page Not Found');
// });


module.exports = router;