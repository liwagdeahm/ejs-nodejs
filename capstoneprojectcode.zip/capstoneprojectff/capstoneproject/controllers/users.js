const db = require('../routes/db-config');
const bcrypt = require('bcryptjs');


exports.register = (req, res) => {
    const {firstname, lastname, email, mobilenum, password: hashedPassword } = req.body;
    db.query('SELECT email FROM user WHERE email = ?', [email], (err, result) => { 
        if (err) {
            confirm.log(error);
        }

        if (result.length > 0) {
            return res.render('register', { msg: "Email has already been registered!"});
        }
    })
};