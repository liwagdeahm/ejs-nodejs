const db = require('../routes/db-config');
const bcrypt = require('bcryptjs');


const register = async (req, res) => {
    const {firstname, lastname, email, mobilenum, password: hashedPassword } = req.body
    if (!email || !hashedPassword) return res.json({ status: "error", error: "Please enter your email and password!" });
    else {
        db.query('SELECT email FROM user WHERE email = ?', [email], async (err, result) => {
            if (err) throw err;
            if (result[0])return res.json({ status: "error", error: "Email has already been registered!" });
            else {
                const password = await bcrypt.hash(hashedPassword, 8);
                db.query('INSERT INTO user SET ?', { firstname:firstname, lastname:lastname, email:email, mobilenum:mobilenum, password:password }, (error, result) => {
                    if (error) throw error;
                    res.redirect('/login')
                    // return res.render('login', { status: "success", success: "User has been registered successfully!" });
                }) 
            }
        })
    } 
}

module.exports = register;


