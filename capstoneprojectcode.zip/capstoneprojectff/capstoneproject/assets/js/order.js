const Orders = [
    {
        productName: 'PE Uniform',
        productNumber: '001',
        paymentStatus: 'Due',
        shipping: 'Completed',
    },

    {
        productName: 'Exploring Life Through Science',
        productNumber: '002',
        paymentStatus: 'Due',
        shipping: 'Ready for pickup',
    },

    {
        productName: 'Mathematics',
        productNumber: '003',
        paymentStatus: 'Due',
        shipping: 'Pending',
    },

    {
        productName: 'Ballpen',
        productNumber: '004',
        paymentStatus: 'Due',
        shipping: 'Declined',
    },

    {
        productName: 'Highlighter Pen',
        productNumber: '005',
        paymentStatus: 'Due',
        shipping: 'Pending',
    },
    

]