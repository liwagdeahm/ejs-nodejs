const search = () => {
    const searchbox = document.getElementById("search-box").value.toUpperCase();
    const productItems = document.getElementById("box-container")
    const product = document.querySelectorAll(".box")
    const pname = document.getElementsByTagName("h3")

    for (var i = 0; i < pname.length; i++) {
        let match = product[i].getElementsByTagName('h3')[0];

        if (match) {
            let textvalue = match.textContent || match.innerHTML

            if (textvalue.toUpperCase().indexOf(searchbox) > -1) {
                product[i].style.display = "";
            } else {
                product[i].style.display = "none";
            }
        }
    }
}