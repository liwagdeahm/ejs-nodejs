const ctx = document.getElementById('myChart');
              
                new Chart(ctx, {
                  type: 'bar',
                  data: {
                    labels: ['Jan', 'Feb', 'Mar', 'April', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'],
                    datasets: [{
                      label: 'Earnings in ₱',
                      data: [2050, 1900, 3100, 3500, 2500, 2800, 3000, 2400, 2600, 1950, 2300, 2900],
                      borderWidth: 1
                    }]
                  },
                  options: {
                    responsive:true
                  }
                });