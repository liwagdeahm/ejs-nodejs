const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');

const app = express();

app.use(cors());

const dbConnect = () => {
    return mysql.createConnection({
        host     : 'localhost',
        user     : 'root',
        password : 'root',
        database : 'root'
    });
}

const getUsers = async () => {
    let connection, rows;

    try {
        connection = await dbConnect();
        [ rows ] = await connection.execute('SELECT * FROM capstone');
    } finally {
        await connection.end();
        return rows;
    }
}

app.get('/api/users', (req, res) => {
    getUsers()
    .then(data => res.json(data))
    .catch(err => res.json('Error'));
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`http://localhost:${PORT}`));

